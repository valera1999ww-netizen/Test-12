from __future__ import annotations

import time
from collections import defaultdict, deque

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject


class RateLimitMiddleware(BaseMiddleware):
    def __init__(self, max_calls: int = 8, period: float = 3.0) -> None:
        super().__init__()
        self.max_calls = max_calls
        self.period = period
        self._events: dict[int, deque[float]] = defaultdict(deque)

    async def __call__(self, handler, event: TelegramObject, data):
        user = data.get("event_from_user")
        if not user:
            return await handler(event, data)
        q = self._events[user.id]
        now = time.monotonic()
        while q and now - q[0] > self.period:
            q.popleft()
        if len(q) >= self.max_calls:
            return None
        q.append(now)
        return await handler(event, data)
