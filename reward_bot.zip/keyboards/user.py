from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def subscribe_keyboard(channel_url: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="📢 ПІДПИСАТИСЯ НА КАНАЛ", url=channel_url))
    builder.row(InlineKeyboardButton(text="✅ ПЕРЕВІРИТИ ПІДПИСКУ", callback_data="check_subscription"))
    return builder.as_markup()


def main_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🎁 Отримати приз", callback_data="spin"))
    builder.row(InlineKeyboardButton(text="📋 Завдання", callback_data="tasks"))
    builder.row(InlineKeyboardButton(text="💰 Мій баланс", callback_data="profile"), InlineKeyboardButton(text="👥 Запросити друзів", callback_data="referrals"))
    builder.row(InlineKeyboardButton(text="💸 Вивести кошти", callback_data="withdraw"), InlineKeyboardButton(text="📜 Історія", callback_data="history"))
    builder.row(InlineKeyboardButton(text="📖 Правила", callback_data="rules"), InlineKeyboardButton(text="📞 Підтримка", callback_data="support"))
    return builder.as_markup()


def back_home() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🏠 Головне меню", callback_data="home")
    return builder.as_markup()


def spin_confirm() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🎁 ОТРИМАТИ ПРИЗ", callback_data="spin_confirm")
    builder.button(text="🏠 Головне меню", callback_data="home")
    return builder.as_markup()


def referral_keyboard(link: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📤 ЗАПРОСИТИ ДРУЗІВ", url=f"https://t.me/share/url?url={link}&text=🎁%20Забирай%20свій%20безкоштовний%20спін!" )
    builder.button(text="🏠 Головне меню", callback_data="home")
    return builder.as_markup()


def task_keyboard(task_id: int, link: str, requires_check: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔗 ВІДКРИТИ", url=link)
    if requires_check:
        builder.button(text="✅ ПЕРЕВІРИТИ", callback_data=f"task:check:{task_id}")
    else:
        builder.button(text="✅ ЗАБРАТИ НАГОРОДУ", callback_data=f"task:claim:{task_id}")
    builder.button(text="⬅️ До завдань", callback_data="tasks")
    return builder.as_markup()


def task_list_keyboard(tasks: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for task_id, name in tasks:
        builder.button(text=f"🎯 {name}", callback_data=f"task:view:{task_id}")
    builder.button(text="🏠 Головне меню", callback_data="home")
    builder.adjust(1)
    return builder.as_markup()


def payout_methods_keyboard(methods: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for method_id, name in methods:
        builder.button(text=f"💳 {name}", callback_data=f"withdraw:method:{method_id}")
    builder.button(text="🏠 Головне меню", callback_data="home")
    builder.adjust(1)
    return builder.as_markup()
