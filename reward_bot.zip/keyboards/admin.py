from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_menu() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    rows = [
        [("📊 Статистика", "admin:stats"), ("👥 Користувачі", "admin:users")],
        [("💰 Баланси", "admin:balance"), ("🎁 Видача спінів", "admin:spins")],
        [("💵 Видача грн", "admin:money"), ("🎯 Завдання", "admin:tasks")],
        [("📢 Розсилка", "admin:broadcast"), ("💸 Виплати", "admin:withdrawals")],
        [("🎲 Шанси призів", "admin:chances"), ("📢 Канали", "admin:channels")],
        [("💳 Способи виплат", "admin:payout_methods"), ("⚙️ Налаштування", "admin:settings")],
        [("📜 Логи", "admin:logs"), ("🏠 Користувацьке меню", "home")],
    ]
    for row in rows:
        b.row(*(InlineKeyboardButton(text=text, callback_data=data) for text, data in row))
    return b.as_markup()


def simple_admin_back(target: str = "admin:menu") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ Назад", callback_data=target)
    b.button(text="🏠 Адмін-панель", callback_data="admin:menu")
    b.adjust(1)
    return b.as_markup()


def confirm_admin(action: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ ПІДТВЕРДИТИ", callback_data=f"admin:confirm:{action}")
    b.button(text="❌ СКАСУВАТИ", callback_data="admin:cancel")
    return b.as_markup()


def task_admin_keyboard(tasks: list[tuple[int, str, bool]]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for task_id, name, active in tasks:
        icon = "🟢" if active else "🔴"
        b.row(
            InlineKeyboardButton(text=f"{icon} {name}", callback_data=f"admin:task:view:{task_id}"),
            InlineKeyboardButton(text="⏻", callback_data=f"admin:task:toggle:{task_id}"),
        )
    b.row(InlineKeyboardButton(text="➕ ДОДАТИ ЗАВДАННЯ", callback_data="admin:task:add"))
    b.row(InlineKeyboardButton(text="🏠 Адмін-панель", callback_data="admin:menu"))
    return b.as_markup()


def payout_admin_keyboard(items: list[tuple[int, str, str]]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for wid, label, status in items:
        b.button(text=f"{status} {label}", callback_data=f"admin:withdraw:view:{wid}")
    b.button(text="🏠 Адмін-панель", callback_data="admin:menu")
    b.adjust(1)
    return b.as_markup()


def withdrawal_action_keyboard(withdrawal_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(text="✅ ВИПЛАЧЕНО", callback_data=f"admin:withdraw:paid:{withdrawal_id}"),
        InlineKeyboardButton(text="❌ ВІДХИЛИТИ", callback_data=f"admin:withdraw:reject:{withdrawal_id}"),
    )
    b.row(InlineKeyboardButton(text="⬅️ До виплат", callback_data="admin:withdrawals"))
    return b.as_markup()


def payout_methods_manage(items: list[tuple[int, str, bool]]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for item_id, name, active in items:
        icon = "🟢" if active else "🔴"
        b.row(
            InlineKeyboardButton(text=f"{icon} {name}", callback_data=f"admin:pm:toggle:{item_id}"),
            InlineKeyboardButton(text="✏️", callback_data=f"admin:pm:edit:{item_id}"),
            InlineKeyboardButton(text="❌", callback_data=f"admin:pm:delete:{item_id}"),
        )
    b.row(InlineKeyboardButton(text="➕ ДОДАТИ СПОСІБ", callback_data="admin:pm:add"))
    b.row(InlineKeyboardButton(text="🏠 Адмін-панель", callback_data="admin:menu"))
    return b.as_markup()


def chance_keyboard(prizes: list[tuple[int, str, str]]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for prize_id, amount, chance in prizes:
        b.button(text=f"{amount} → {chance}%", callback_data=f"admin:chance:edit:{prize_id}")
    b.button(text="🏠 Адмін-панель", callback_data="admin:menu")
    b.adjust(1)
    return b.as_markup()
