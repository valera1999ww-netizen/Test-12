from __future__ import annotations

import random
from decimal import Decimal

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import Prize, Spin, Transaction, User


async def choose_prize(session: AsyncSession) -> Prize:
    prizes = (await session.execute(select(Prize).where(Prize.is_active.is_(True)).order_by(Prize.sort_order, Prize.id))).scalars().all()
    if not prizes:
        raise RuntimeError("Немає активних призів")
    total = sum((Decimal(p.chance) for p in prizes), Decimal("0"))
    if abs(total - Decimal("100")) > Decimal("0.0001"):
        raise RuntimeError("Сума шансів призів має дорівнювати 100%")
    point = Decimal(str(random.uniform(0, float(total))))
    cumulative = Decimal("0")
    for prize in prizes:
        cumulative += Decimal(prize.chance)
        if point < cumulative:
            return prize
    return prizes[-1]


async def perform_spin(session: AsyncSession, telegram_id: int) -> Prize:
    user = (await session.execute(select(User).where(User.telegram_id == telegram_id).with_for_update())).scalar_one()
    if user.spins <= 0:
        raise ValueError("У тебе немає доступних спінів")
    prize = await choose_prize(session)
    user.spins -= 1
    amount = Decimal(prize.amount)
    user.balance += amount
    user.total_won += amount
    session.add(Spin(user_id=user.id, prize_id=prize.id, amount=amount))
    session.add(Transaction(
        user_id=user.id,
        tx_type="spin",
        amount=amount,
        balance_after=user.balance,
        description=f"🎁 Виграш у спіні: +{amount} грн",
        meta={"prize_id": prize.id},
    ))
    await session.flush()
    return prize
