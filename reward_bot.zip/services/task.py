from __future__ import annotations

from decimal import Decimal

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import Task, TaskCompletion, Transaction, User


async def is_channel_member(bot: Bot, chat_id: str, telegram_id: int) -> bool:
    try:
        member = await bot.get_chat_member(chat_id=chat_id, user_id=telegram_id)
        return member.status in {"member", "administrator", "creator"}
    except TelegramBadRequest:
        return False


async def complete_task(session: AsyncSession, user: User, task: Task) -> Decimal:
    locked_user = (await session.execute(select(User).where(User.id == user.id).with_for_update())).scalar_one()
    locked_task = (await session.execute(select(Task).where(Task.id == task.id).with_for_update())).scalar_one()
    exists = await session.execute(
        select(TaskCompletion.id).where(TaskCompletion.task_id == locked_task.id, TaskCompletion.user_id == locked_user.id)
    )
    if exists.scalar_one_or_none() is not None:
        raise ValueError("Це завдання вже виконано")
    if not locked_task.is_active:
        raise ValueError("Завдання більше неактивне")
    if locked_task.max_completions is not None:
        count = (await session.execute(select(func.count()).select_from(TaskCompletion).where(TaskCompletion.task_id == locked_task.id))).scalar_one()
        if count >= locked_task.max_completions:
            raise ValueError("Ліміт виконань цього завдання вже вичерпано")
    reward = Decimal(locked_task.reward)
    locked_user.balance += reward
    locked_user.tasks_completed += 1
    locked_user.total_won += reward
    session.add(TaskCompletion(task_id=locked_task.id, user_id=locked_user.id, reward=reward))
    session.add(Transaction(
        user_id=locked_user.id,
        tx_type="task",
        amount=reward,
        balance_after=locked_user.balance,
        description=f"📋 Виконано завдання: {locked_task.name}",
        meta={"task_id": locked_task.id},
    ))
    await session.flush()
    return reward
