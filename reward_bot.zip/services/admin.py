from __future__ import annotations

from datetime import datetime, timezone, timedelta
from decimal import Decimal

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import AdminLog, Broadcast, PayoutMethod, Prize, Setting, Task, Transaction, User, Withdrawal
from utils.formatting import money


def is_admin(telegram_id: int, admin_ids: tuple[int, ...]) -> bool:
    return telegram_id in admin_ids


async def log_admin(session: AsyncSession, admin_id: int, action: str, target_user_id: int | None = None, payload: dict | None = None) -> None:
    session.add(AdminLog(admin_telegram_id=admin_id, action=action, target_user_id=target_user_id, payload=payload))


async def admin_stats(session: AsyncSession) -> dict:
    now = datetime.now(timezone.utc)
    day = now - timedelta(days=1)
    week = now - timedelta(days=7)
    return {
        "users": (await session.execute(select(func.count()).select_from(User))).scalar_one(),
        "active": (await session.execute(select(func.count()).select_from(User).where(User.last_activity_at >= day))).scalar_one(),
        "new_today": (await session.execute(select(func.count()).select_from(User).where(User.created_at >= day))).scalar_one(),
        "new_7d": (await session.execute(select(func.count()).select_from(User).where(User.created_at >= week))).scalar_one(),
        "spins": (await session.execute(select(func.count()).select_from(Transaction).where(Transaction.tx_type == "spin"))).scalar_one(),
        "credited": (await session.execute(select(func.coalesce(func.sum(Transaction.amount), 0)).where(Transaction.tx_type.in_(["spin", "task", "admin_credit"]), Transaction.amount > 0))).scalar_one(),
        "paid": (await session.execute(select(func.coalesce(func.sum(User.total_paid), 0)))).scalar_one(),
        "tasks": (await session.execute(select(func.count()).select_from(Transaction).where(Transaction.tx_type == "task"))).scalar_one(),
        "referrals": (await session.execute(select(func.coalesce(func.sum(User.referral_count), 0)))).scalar_one(),
    }


async def seed_data(session: AsyncSession, min_withdrawal: Decimal) -> None:
    if (await session.execute(select(func.count()).select_from(Prize))).scalar_one() == 0:
        defaults = [(10, 30), (20, 25), (30, 20), (50, 12), (100, 7), (200, 4), (300, 2)]
        for idx, (amount, chance) in enumerate(defaults):
            session.add(Prize(amount=Decimal(amount), chance=Decimal(chance), sort_order=idx))
    if (await session.execute(select(func.count()).select_from(PayoutMethod))).scalar_one() == 0:
        session.add(PayoutMethod(name="Банківська картка", slug="bank_card", is_active=True, sort_order=1))
        session.add(PayoutMethod(name="Інший доступний спосіб", slug="other", is_active=True, sort_order=2))

    settings_defaults = {
        "min_withdrawal": str(min_withdrawal),
    }
    for key, value in settings_defaults.items():
        existing = await session.get(Setting, key)
        if existing is None:
            session.add(Setting(key=key, value=value))
    await session.commit()


async def get_setting(session: AsyncSession, key: str, default: str) -> str:
    item = await session.get(Setting, key)
    return item.value if item else default


async def set_setting(session: AsyncSession, key: str, value: str) -> None:
    item = await session.get(Setting, key)
    if item is None:
        session.add(Setting(key=key, value=value))
    else:
        item.value = value
