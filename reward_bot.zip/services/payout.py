from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import PayoutMethod, Transaction, User, Withdrawal


async def create_withdrawal(session: AsyncSession, telegram_id: int, method_id: int, amount: Decimal, details: str, min_amount: Decimal) -> Withdrawal:
    user = (await session.execute(select(User).where(User.telegram_id == telegram_id).with_for_update())).scalar_one()
    if amount < min_amount:
        raise ValueError(f"Мінімальна виплата — {min_amount} грн")
    if amount > user.balance:
        raise ValueError("Недостатньо коштів на балансі")
    method = (await session.execute(select(PayoutMethod).where(PayoutMethod.id == method_id, PayoutMethod.is_active.is_(True)))).scalar_one_or_none()
    if not method:
        raise ValueError("Спосіб виплати недоступний")
    withdrawal = Withdrawal(
        user_id=user.id,
        method_id=method.id,
        amount=amount,
        payment_details=details,
        status="pending",
    )
    user.balance -= amount
    session.add(withdrawal)
    await session.flush()
    session.add(Transaction(
        user_id=user.id,
        tx_type="withdrawal_hold",
        amount=-amount,
        balance_after=user.balance,
        description=f"💸 Резерв виплати #{withdrawal.id}",
    ))
    await session.flush()
    return withdrawal


async def approve_withdrawal(session: AsyncSession, withdrawal_id: int) -> Withdrawal:
    w = (await session.execute(select(Withdrawal).where(Withdrawal.id == withdrawal_id).with_for_update())).scalar_one()
    if w.status != "pending":
        raise ValueError("Заявка вже оброблена")
    user = await session.get(User, w.user_id, with_for_update=True)
    w.status = "paid"
    w.processed_at = datetime.now(timezone.utc)
    user.total_paid += Decimal(w.amount)
    session.add(Transaction(
        user_id=user.id,
        tx_type="withdrawal_paid",
        amount=0,
        balance_after=user.balance,
        description=f"✅ Виплату #{w.id} підтверджено",
    ))
    await session.flush()
    return w


async def reject_withdrawal(session: AsyncSession, withdrawal_id: int, note: str | None = None) -> Withdrawal:
    w = (await session.execute(select(Withdrawal).where(Withdrawal.id == withdrawal_id).with_for_update())).scalar_one()
    if w.status != "pending":
        raise ValueError("Заявка вже оброблена")
    user = await session.get(User, w.user_id, with_for_update=True)
    amount = Decimal(w.amount)
    user.balance += amount
    w.status = "rejected"
    w.admin_note = note
    w.processed_at = datetime.now(timezone.utc)
    session.add(Transaction(
        user_id=user.id,
        tx_type="withdrawal_refund",
        amount=amount,
        balance_after=user.balance,
        description=f"↩️ Повернення за відхилену виплату #{w.id}",
    ))
    await session.flush()
    return w
