from __future__ import annotations

from datetime import datetime, timezone, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import User


async def get_or_create_user(session: AsyncSession, telegram_user) -> User:
    result = await session.execute(select(User).where(User.telegram_id == telegram_user.id))
    user = result.scalar_one_or_none()
    if user is None:
        user = User(
            telegram_id=telegram_user.id,
            username=telegram_user.username,
            first_name=telegram_user.first_name or "",
        )
        session.add(user)
        await session.flush()
    else:
        user.username = telegram_user.username
        user.first_name = telegram_user.first_name or user.first_name
        user.last_activity_at = datetime.now(timezone.utc)
    return user


async def get_user_by_tg(session: AsyncSession, telegram_id: int) -> User | None:
    return (await session.execute(select(User).where(User.telegram_id == telegram_id))).scalar_one_or_none()


async def get_stats(session: AsyncSession) -> dict[str, int | Decimal]:
    now = datetime.now(timezone.utc)
    day = now - timedelta(days=1)
    week = now - timedelta(days=7)
    total = (await session.execute(select(func.count()).select_from(User))).scalar_one()
    active = (await session.execute(select(func.count()).select_from(User).where(User.last_activity_at >= day))).scalar_one()
    today = (await session.execute(select(func.count()).select_from(User).where(User.created_at >= day))).scalar_one()
    seven = (await session.execute(select(func.count()).select_from(User).where(User.created_at >= week))).scalar_one()
    return {"total": total, "active": active, "today": today, "seven": seven}
