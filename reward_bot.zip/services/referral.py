from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import Referral, Transaction, User


async def attach_referrer(session: AsyncSession, user: User, referrer_telegram_id: int | None) -> bool:
    if not referrer_telegram_id or referrer_telegram_id == user.telegram_id or user.referrer_id:
        return False
    result = await session.execute(select(User).where(User.telegram_id == referrer_telegram_id))
    referrer = result.scalar_one_or_none()
    if not referrer or referrer.id == user.id:
        return False
    user.referrer_id = referrer.id
    return True


async def activate_referral(session: AsyncSession, user: User) -> int:
    if not user.referrer_id:
        return 0
    existing = await session.execute(select(Referral).where(Referral.referred_id == user.id))
    if existing.scalar_one_or_none():
        return 0
    referrer = await session.get(User, user.referrer_id, with_for_update=True)
    if not referrer:
        return 0
    session.add(Referral(referrer_id=referrer.id, referred_id=user.id))
    referrer.referral_count += 1
    eligible_spins = referrer.referral_count // 3
    new_spins = max(0, eligible_spins - referrer.referral_spins_awarded)
    if new_spins:
        referrer.spins += new_spins
        referrer.referral_spins_awarded += new_spins
        session.add(Transaction(
            user_id=referrer.id,
            tx_type="referral_spin",
            amount=0,
            balance_after=referrer.balance,
            description=f"🎁 Бонус за рефералів: +{new_spins} спін(ів)",
        ))
    return new_spins
