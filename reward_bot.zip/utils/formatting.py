from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from html import escape


def money(value: Decimal | int | float) -> str:
    amount = Decimal(str(value)).quantize(Decimal("0.01"))
    if amount == amount.to_integral():
        return f"{int(amount)} грн"
    return f"{amount:.2f} грн"


def tg_user_label(username: str | None, first_name: str, telegram_id: int) -> str:
    if username:
        return f"@{escape(username.lstrip('@'))}"
    return f"{escape(first_name)} (<code>{telegram_id}</code>)"


def dt(value: datetime) -> str:
    local = value.astimezone()
    return local.strftime("%d.%m.%Y %H:%M")
