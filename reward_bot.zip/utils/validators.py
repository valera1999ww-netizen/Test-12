from __future__ import annotations

from decimal import Decimal, InvalidOperation
import re
from urllib.parse import urlparse


def parse_decimal(text: str, min_value: Decimal | None = None, max_value: Decimal | None = None) -> Decimal | None:
    try:
        value = Decimal(text.replace(",", ".").strip())
    except (InvalidOperation, AttributeError):
        return None
    if min_value is not None and value < min_value:
        return None
    if max_value is not None and value > max_value:
        return None
    return value


def parse_int(text: str, min_value: int | None = None, max_value: int | None = None) -> int | None:
    try:
        value = int(text.strip())
    except (ValueError, AttributeError):
        return None
    if min_value is not None and value < min_value:
        return None
    if max_value is not None and value > max_value:
        return None
    return value


def valid_url(text: str) -> bool:
    try:
        parsed = urlparse(text.strip())
        return parsed.scheme in {"http", "https", "tg"} and bool(parsed.netloc or parsed.path)
    except Exception:
        return False


def card_digits(text: str) -> str | None:
    digits = re.sub(r"\D", "", text)
    if 12 <= len(digits) <= 19:
        return digits
    return None


def mask_card(card: str) -> str:
    digits = re.sub(r"\D", "", card)
    if not digits:
        return "****"
    return "**** **** **** " + digits[-4:]
