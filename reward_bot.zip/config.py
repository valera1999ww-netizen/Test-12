from __future__ import annotations

import os
from dataclasses import dataclass
from decimal import Decimal

from dotenv import load_dotenv

load_dotenv()


def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _int_list(value: str) -> list[int]:
    if not value.strip():
        return []
    result: list[int] = []
    for item in value.split(","):
        item = item.strip()
        if item:
            result.append(int(item))
    return result


def _decimal(value: str, default: str) -> Decimal:
    raw = value.strip() if value else default
    return Decimal(raw)


@dataclass(frozen=True, slots=True)
class Settings:
    bot_token: str
    admin_ids: tuple[int, ...]
    database_url: str
    required_channel_id: str
    required_channel_url: str
    support_username: str
    cooperation_username: str
    min_withdrawal: Decimal
    web_host: str
    web_port: int
    log_level: str

    @classmethod
    def from_env(cls) -> "Settings":
        admin_ids = tuple(_int_list(os.getenv("ADMIN_IDS", "")))
        if not admin_ids:
            raise RuntimeError("ADMIN_IDS must contain at least one Telegram ID")
        database_url = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./reward_bot.db").strip()
        if database_url.startswith("postgresql://"):
            database_url = "postgresql+asyncpg://" + database_url.removeprefix("postgresql://")
        elif database_url.startswith("postgres://"):
            database_url = "postgresql+asyncpg://" + database_url.removeprefix("postgres://")
        elif database_url.startswith("sqlite://") and not database_url.startswith("sqlite+aiosqlite://"):
            database_url = "sqlite+aiosqlite://" + database_url.removeprefix("sqlite://")
        return cls(
            bot_token=_required("BOT_TOKEN"),
            admin_ids=admin_ids,
            database_url=database_url,
            required_channel_id=_required("REQUIRED_CHANNEL_ID"),
            required_channel_url=_required("REQUIRED_CHANNEL_URL"),
            support_username=os.getenv("SUPPORT_USERNAME", "@ua_101"),
            cooperation_username=os.getenv("COOPERATION_USERNAME", "@ua_101"),
            min_withdrawal=_decimal(os.getenv("MIN_WITHDRAWAL", "50"), "50"),
            web_host=os.getenv("WEB_HOST", "0.0.0.0"),
            web_port=int(os.getenv("PORT", "10000")),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
        )


settings = Settings.from_env()
