from __future__ import annotations

import asyncio
import logging
import sys
from contextlib import suppress

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from uvicorn import Config as UvicornConfig, Server

from config import settings
from database.session import SessionLocal, engine, init_db
from handlers import admin, errors, user, withdraw
from middlewares.throttling import RateLimitMiddleware
from services.admin import seed_data

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("reward_bot")


bot_instance: Bot

app = FastAPI(title="Reward Telegram Bot", docs_url=None, redoc_url=None)


@app.get("/")
async def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.get("/health")
async def health_alias() -> JSONResponse:
    return JSONResponse({"status": "ok"})


async def run() -> None:
    global bot_instance
    await init_db()
    async with SessionLocal() as session:
        await seed_data(session, settings.min_withdrawal)

    bot_instance = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()
    dp.message.middleware(RateLimitMiddleware(max_calls=10, period=3.0))
    dp.callback_query.middleware(RateLimitMiddleware(max_calls=15, period=3.0))
    dp.include_router(errors.router)
    dp.include_router(admin.router)
    dp.include_router(withdraw.router)
    dp.include_router(user.router)

    me = await bot_instance.get_me()
    logger.info("Bot started: @%s", me.username)
    logger.info("Database: %s", settings.database_url.split("@")[0])

    uvicorn_server = Server(UvicornConfig(app, host=settings.web_host, port=settings.web_port, log_level=settings.log_level.lower()))
    server_task = asyncio.create_task(uvicorn_server.serve(), name="fastapi-server")
    polling_task = asyncio.create_task(
        dp.start_polling(bot_instance, allowed_updates=dp.resolve_used_update_types()),
        name="telegram-polling",
    )
    try:
        done, pending = await asyncio.wait({server_task, polling_task}, return_when=asyncio.FIRST_EXCEPTION)
        for task in done:
            exc = task.exception()
            if exc:
                raise exc
    finally:
        for task in (server_task, polling_task):
            task.cancel()
        for task in (server_task, polling_task):
            with suppress(asyncio.CancelledError):
                await task
        await bot_instance.session.close()
        await engine.dispose()
        logger.info("Bot stopped")


if __name__ == "__main__":
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        logging.getLogger("reward_bot").info("Interrupted by user")
