# Reward Zone — Telegram reward bot

Production-oriented Telegram reward bot built with Python 3.12+, aiogram 3.x, SQLAlchemy 2.x, PostgreSQL/asyncpg, FastAPI/Uvicorn and long polling.

## Features

- Mandatory subscription gate on `/start`.
- One-time starter spin after successful subscription verification.
- Server-side weighted prize selection before the Telegram animation starts.
- Atomic spin deduction + balance credit.
- Referral deep links with `?start=ref_USER_ID`.
- Every 3 activated referrals → +1 spin.
- Task system with subscription, channel-view/click, link and custom types.
- Duplicate-task protection and completion limits.
- Withdrawal requests with configurable payout methods.
- Funds are reserved atomically when a withdrawal is created.
- Paid withdrawals stay deducted; rejected withdrawals are refunded atomically.
- Admin panel restricted by `ADMIN_IDS`.
- Prize chance editor with strict 100% validation.
- Broadcasts with text/photo/video and optional URL button.
- PostgreSQL for production; SQLite supported for local testing.
- FastAPI health endpoint at `/` and `/health`.
- Long polling only — no Web App and no browser roulette.

## Important Telegram setup

Add the bot as an administrator to the required channel. Membership checks for other users depend on the bot having the needed access to the channel.

For task subscription checks, the bot must also have enough access to the target channel. The bot never claims it can verify that a user actually read a specific Telegram post; a `view_channel` task uses only an available membership/click-based signal and tells the user about that limitation.

## Environment

Copy `.env.example` to `.env` for local use. For Render, set the same variables in the service environment.

Required:

- `BOT_TOKEN`
- `ADMIN_IDS`
- `DATABASE_URL`
- `REQUIRED_CHANNEL_ID`
- `REQUIRED_CHANNEL_URL`

For Render PostgreSQL, use a SQLAlchemy async URL such as:

`postgresql+asyncpg://USER:PASSWORD@HOST:5432/DATABASE`

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python bot.py
```

Windows PowerShell activation:

```powershell
.venv\Scripts\Activate.ps1
```

## Render

1. Create a Render PostgreSQL database.
2. Create a Render Web Service from this project.
3. Use `render.yaml` or configure the values manually.
4. Set `DATABASE_URL` to the Render PostgreSQL async URL.
5. Deploy with the start command `python bot.py`.
6. The health endpoint is `GET /` and returns `{"status":"ok"}`.

The bot uses long polling, so there is no webhook configuration and no public Telegram webhook URL requirement.

## Project structure

```text
reward_bot/
├── bot.py
├── config.py
├── requirements.txt
├── render.yaml
├── .env.example
├── README.md
├── database/
│   ├── base.py
│   ├── models.py
│   └── session.py
├── handlers/
│   ├── admin.py
│   ├── errors.py
│   ├── user.py
│   └── withdraw.py
├── keyboards/
│   ├── admin.py
│   └── user.py
├── middlewares/
│   └── throttling.py
├── services/
│   ├── admin.py
│   ├── payout.py
│   ├── referral.py
│   ├── spin.py
│   ├── task.py
│   └── user.py
└── utils/
    ├── formatting.py
    └── validators.py
```

## Security notes

- Never commit the real `.env` file.
- Rotate a bot token immediately if it was ever exposed publicly.
- Use PostgreSQL in production.
- Keep only trusted Telegram IDs in `ADMIN_IDS`.
- For real financial payouts, treat the admin approval screen as the final operational control; this bot reserves the user's balance at request creation to eliminate double-spend risk.
