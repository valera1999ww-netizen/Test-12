from __future__ import annotations

import asyncio
from decimal import Decimal
from html import escape

from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from config import settings
from database.models import PayoutMethod, Prize, Task, TaskCompletion, Transaction, User
from database.session import SessionLocal
from keyboards.user import (
    back_home,
    main_menu,
    payout_methods_keyboard,
    referral_keyboard,
    spin_confirm,
    subscribe_keyboard,
    task_keyboard,
    task_list_keyboard,
)
from services.admin import get_setting
from services.referral import activate_referral, attach_referrer
from services.spin import perform_spin
from services.task import complete_task, is_channel_member
from services.user import get_or_create_user
from utils.formatting import dt, money, tg_user_label

router = Router(name="user")

RULES_TEXT = """📖 <b>ПРАВИЛА БОТА</b>

1️⃣ <b>Реєстрація</b>
Для користування ботом необхідно пройти реєстрацію та підтвердити підписку на основний канал.

2️⃣ <b>Безкоштовний спін</b>
Кожен новий користувач після успішної перевірки підписки отримує 1 безкоштовний спін.

3️⃣ <b>Реферальна система</b>
За кожних 3 реальних запрошених користувачів нараховується 1 додатковий спін.

4️⃣ <b>Завдання</b>
За виконання доступних завдань користувач може отримувати винагороди.

5️⃣ <b>Призи</b>
Доступні призи: 10 / 20 / 30 / 50 / 100 / 200 / 300 грн.
Шанс кожного призу визначається поточними налаштуваннями системи.

6️⃣ <b>Виплати</b>
Виплата доступна після досягнення мінімального балансу, встановленого адміністрацією.

7️⃣ <b>Заборонено</b>
Заборонені мультиакаунти, автоматичне виконання завдань, шахрайство, накрутка рефералів та використання ботів для обходу системи.

8️⃣ <b>Перевірки</b>
Адміністрація має право перевіряти підозрілу активність і запитувати додаткові підтвердження.

9️⃣ <b>Блокування</b>
У випадку порушення правил акаунт може бути обмежений або заблокований відповідно до правил сервісу.

🔟 <b>Підтримка</b>
З усіх питань звертайтесь до адміністратора.
"""


def home_text(user: User) -> str:
    return (
        "🌑 <b>REWARD ZONE</b> ✨\n\n"
        f"👋 Вітаємо, <b>{escape(user.first_name)}</b>!\n\n"
        "💰 Виконуй прості дії, отримуй бонуси, крути спіни та накопичуй баланс.\n\n"
        f"💳 Баланс: <b>{money(user.balance)}</b>\n"
        f"🎁 Спінів: <b>{user.spins}</b>\n\n"
        "👇 <b>Обери потрібний розділ:</b>"
    )


async def ensure_gate(message: Message | CallbackQuery) -> bool:
    user_id = message.from_user.id
    async with SessionLocal() as session:
        user = await get_or_create_user(session, message.from_user)
        await session.commit()
        if user.is_blocked:
            text = "🚫 <b>Доступ обмежено.</b>\n\nЗвернись до адміністратора: @ua_101"
            if isinstance(message, CallbackQuery):
                await message.answer("Доступ обмежено", show_alert=True)
            else:
                await message.answer(text)
            return False
    if await _is_subscribed(user_id):
        return True
    text = (
        "🎁 <b>ВІТАЄМО У REWARD ZONE!</b> ✨\n\n"
        "💰 Тут ти можеш отримувати реальні винагороди за прості дії.\n\n"
        "🎁 <b>Твій стартовий бонус — 1 безкоштовний спін!</b>\n\n"
        "Щоб почати користуватися ботом, спочатку підпишись на канал і натисни перевірку."
    )
    markup = subscribe_keyboard(settings.required_channel_url)
    if isinstance(message, CallbackQuery):
        await message.message.edit_text(text, reply_markup=markup)
        await message.answer()
    else:
        await message.answer(text, reply_markup=markup)
    return False


async def _is_subscribed(telegram_id: int) -> bool:
    # Bot API reliably verifies another user's membership when the bot is an administrator of the channel.
    from bot import bot_instance
    return await is_channel_member(bot_instance, settings.required_channel_id, telegram_id)


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    payload = ""
    if message.text and " " in message.text:
        payload = message.text.split(" ", 1)[1].strip()
    referrer_id = None
    if payload.startswith("ref_"):
        try:
            referrer_id = int(payload[4:])
        except ValueError:
            referrer_id = None

    async with SessionLocal() as session:
        user = await get_or_create_user(session, message.from_user)
        if referrer_id:
            await attach_referrer(session, user, referrer_id)
        await session.commit()

    if not await ensure_gate(message):
        return
    await show_home(message)


@router.callback_query(F.data == "check_subscription")
async def check_subscription(callback: CallbackQuery) -> None:
    if not await _is_subscribed(callback.from_user.id):
        await callback.answer("❌ Підписку ще не підтверджено. Спочатку підпишись на канал.", show_alert=True)
        return
    async with SessionLocal() as session:
        async with session.begin():
            user = await get_or_create_user(session, callback.from_user)
            awarded_ref_spins = 0
            if not user.starter_spin_awarded:
                user.starter_spin_awarded = True
                user.spins += 1
                awarded_ref_spins = await activate_referral(session, user)
    extra = f"\n👥 За рефералів нових спінів: <b>+{awarded_ref_spins}</b>" if awarded_ref_spins else ""
    text = "🎉 <b>ПІДПИСКУ ПІДТВЕРДЖЕНО!</b>\n\n🎁 Тобі нараховано <b>1 безкоштовний спін</b>." + extra
    await callback.message.edit_text(text, reply_markup=main_menu())
    await callback.answer("✅ Готово!")


async def show_home(target: Message | CallbackQuery) -> None:
    async with SessionLocal() as session:
        user = await get_or_create_user(session, target.from_user)
        await session.commit()
    text = home_text(user)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=main_menu())
        await target.answer()
    else:
        await target.answer(text, reply_markup=main_menu())


@router.callback_query(F.data == "home")
async def cb_home(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    await show_home(callback)


@router.callback_query(F.data == "profile")
async def profile(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        await session.commit()
    text = (
        "👤 <b>МІЙ ПРОФІЛЬ</b>\n\n"
        f"💰 Баланс: <b>{money(user.balance)}</b>\n"
        f"🎁 Спінів: <b>{user.spins}</b>\n"
        f"👥 Запрошено друзів: <b>{user.referral_count}</b>\n"
        f"🎯 Виконано завдань: <b>{user.tasks_completed}</b>\n"
        f"💸 Всього отримано: <b>{money(user.total_won)}</b>\n"
        f"💳 Всього виплачено: <b>{money(user.total_paid)}</b>"
    )
    await callback.message.edit_text(text, reply_markup=main_menu())
    await callback.answer()


@router.callback_query(F.data == "spin")
async def spin_preview(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        prizes = (await session.execute(select(Prize).where(Prize.is_active.is_(True)).order_by(Prize.sort_order, Prize.id))).scalars().all()
        await session.commit()
    if user.spins <= 0:
        await callback.message.edit_text("🎁 <b>СПІНІВ НЕМАЄ</b>\n\nЗапрошуй друзів або виконуй завдання, щоб отримувати додаткові спіни.", reply_markup=main_menu())
        await callback.answer()
        return
    icons = {Decimal("10"): "💰", Decimal("20"): "💰", Decimal("30"): "💰", Decimal("50"): "⭐", Decimal("100"): "💎", Decimal("200"): "💎", Decimal("300"): "🔥"}
    prize_lines = "\n".join(
        f"{icons.get(Decimal(p.amount), '🎁')} <b>{money(p.amount)}</b>"
        for p in prizes
    )
    text = f"🎁 <b>МОЖЛИВІ ПРИЗИ:</b>\n\n{prize_lines}\n\n🎁 Доступних спінів: <b>{user.spins}</b>"
    await callback.message.edit_text(text, reply_markup=spin_confirm())
    await callback.answer()


@router.callback_query(F.data == "spin_confirm")
async def spin_confirm_handler(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        try:
            async with session.begin():
                prize = await perform_spin(session, callback.from_user.id)
        except ValueError as exc:
            await callback.answer(str(exc), show_alert=True)
            return
        except RuntimeError as exc:
            await callback.answer(str(exc), show_alert=True)
            return
    prize_amount = Decimal(prize.amount)
    async with SessionLocal() as session:
        active_prizes = (await session.execute(select(Prize).where(Prize.is_active.is_(True)).order_by(Prize.sort_order, Prize.id))).scalars().all()
        await session.commit()
    sequence = [Decimal(p.amount) for p in active_prizes]
    if prize_amount not in sequence:
        sequence.append(prize_amount)
    sequence = list(dict.fromkeys(sequence))
    prize_index = sequence.index(prize_amount)
    await callback.message.edit_text(
        "🎁 <b>ВИЗНАЧАЄМО ТВОЇЙ ПРИЗ...</b>\n\n" + "\n".join(f"💰 <b>{money(v)}</b>" for v in sequence)
    )
    await asyncio.sleep(0.7)
    steps = max(8, min(16, len(sequence) * 2 + 6))
    for index in range(steps):
        center_index = (prize_index + steps - index) % len(sequence)
        lines = []
        for offset in (-2, -1, 0, 1, 2):
            value = sequence[(center_index + offset) % len(sequence)]
            if offset == 0:
                lines.append(f"👉 <b>{money(value)}</b> 👈")
            else:
                lines.append(f"▫️ {money(value)}")
        await callback.message.edit_text("🎁 <b>ВИЗНАЧАЄМО ТВІЙ ПРИЗ...</b>\n\n" + "\n".join(lines))
        await asyncio.sleep(0.12 + min(index, 8) * 0.05)
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        await session.commit()
    await callback.message.edit_text(
        "🎉 <b>ВИГРАШ ВИЗНАЧЕНО!</b>\n\n"
        f"💰 <b>+{money(prize_amount)}</b>\n\n"
        f"💳 Баланс: <b>{money(user.balance)}</b>\n"
        f"🎁 Залишилось спінів: <b>{user.spins}</b>",
        reply_markup=main_menu(),
    )
    await callback.answer("🎉 Вітаємо!")


@router.callback_query(F.data == "referrals")
async def referrals(callback: CallbackQuery, bot: Bot) -> None:
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        await session.commit()
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start=ref_{user.telegram_id}"
    remainder = (3 - (user.referral_count % 3)) % 3
    text = (
        "👥 <b>ТВОЯ РЕФЕРАЛЬНА СИСТЕМА</b>\n\n"
        f"Запрошено: <b>{user.referral_count}</b>\n"
        f"До наступного спіну: <b>{remainder}</b>\n"
        f"🎁 Отримано спінів за друзів: <b>{user.referral_spins_awarded}</b>\n\n"
        f"🔗 Твоє посилання:\n<code>{escape(link)}</code>"
    )
    await callback.message.edit_text(text, reply_markup=referral_keyboard(link))
    await callback.answer()


@router.callback_query(F.data == "tasks")
async def tasks(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        task_rows = (await session.execute(select(Task).where(Task.is_active.is_(True)).order_by(Task.sort_order, Task.id))).scalars().all()
        if task_rows:
            completions = (await session.execute(select(TaskCompletion.task_id).where(TaskCompletion.user_id == (await get_or_create_user(session, callback.from_user)).id))).scalars().all()
        else:
            completions = []
        await session.commit()
    completed_ids = set(completions)
    available = [(t.id, t.name) for t in task_rows if t.id not in completed_ids]
    if not available:
        await callback.message.edit_text("📋 <b>ЗАВДАННЯ</b>\n\n✨ Наразі всі доступні завдання виконані або нових завдань немає.", reply_markup=back_home())
    else:
        await callback.message.edit_text("📋 <b>ДОСТУПНІ ЗАВДАННЯ</b>\n\nОбери завдання нижче 👇", reply_markup=task_list_keyboard(available))
    await callback.answer()


@router.callback_query(F.data.startswith("task:view:"))
async def task_view(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    task_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        task = await session.get(Task, task_id)
        user = await get_or_create_user(session, callback.from_user)
        done = None
        if task:
            done = (await session.execute(select(TaskCompletion.id).where(TaskCompletion.task_id == task.id, TaskCompletion.user_id == user.id))).scalar_one_or_none()
        await session.commit()
    if not task or not task.is_active:
        await callback.answer("Завдання недоступне", show_alert=True)
        return
    if done:
        await callback.answer("Це завдання вже виконано", show_alert=True)
        return
    check_note = "✅ Після переходу натисни перевірку." if task.requires_check else "✅ Після переходу натисни кнопку отримання винагороди."
    text = f"🎯 <b>{escape(task.name)}</b>\n\n<i>{escape(task.description)}</i>\n\n💰 Нагорода: <b>{money(task.reward)}</b>\n\n{check_note}"
    if task.task_type == "view_channel" and task.requires_check:
        text += "\n\nℹ️ Telegram не надає боту достовірного сигналу про прочитання конкретного поста. Тут перевіряється доступний факт підписки/участі, а не саме читання."
    await callback.message.edit_text(text, reply_markup=task_keyboard(task.id, task.link, task.requires_check))
    await callback.answer()


@router.callback_query(F.data.startswith("task:check:"))
async def task_check(callback: CallbackQuery, bot: Bot) -> None:
    if not await ensure_gate(callback):
        return
    task_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        task = await session.get(Task, task_id)
        user = await get_or_create_user(session, callback.from_user)
        await session.commit()
    if not task or not task.is_active:
        await callback.answer("Завдання недоступне", show_alert=True)
        return
    check_ok = False
    if task.task_type in {"subscription", "view_channel"}:
        channel_target = _extract_channel_target(task.link)
        if channel_target:
            check_ok = await is_channel_member(bot, channel_target, callback.from_user.id)
    else:
        check_ok = True
    if not check_ok:
        await callback.answer("❌ Перевірку не пройдено. Переконайся, що умову виконано.", show_alert=True)
        return
    async with SessionLocal() as session:
        async with session.begin():
            locked_task = await session.get(Task, task_id)
            locked_user = await get_or_create_user(session, callback.from_user)
            try:
                reward = await complete_task(session, locked_user, locked_task)
            except ValueError as exc:
                await callback.answer(str(exc), show_alert=True)
                return
            balance = locked_user.balance
    await callback.message.edit_text(f"🎉 <b>Завдання виконано!</b>\n\n💰 <b>+{money(reward)}</b>\n💳 Баланс: <b>{money(balance)}</b>", reply_markup=back_home())
    await callback.answer("✅ Нараховано!")


@router.callback_query(F.data.startswith("task:claim:"))
async def task_claim(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    task_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        async with session.begin():
            task = await session.get(Task, task_id)
            user = await get_or_create_user(session, callback.from_user)
            if not task or not task.is_active:
                await callback.answer("Завдання недоступне", show_alert=True)
                return
            try:
                reward = await complete_task(session, user, task)
            except ValueError as exc:
                await callback.answer(str(exc), show_alert=True)
                return
            balance = user.balance
    await callback.message.edit_text(f"🎉 <b>Завдання виконано!</b>\n\n💰 <b>+{money(reward)}</b>\n💳 Баланс: <b>{money(balance)}</b>", reply_markup=back_home())
    await callback.answer("✅ Нараховано!")


def _extract_channel_target(link: str) -> str | None:
    link = link.strip()
    if link.startswith("https://t.me/"):
        tail = link.removeprefix("https://t.me/").split("/", 1)[0].split("?", 1)[0]
        if tail and not tail.startswith("+"):
            return "@" + tail if not tail.startswith("@") else tail
    if link.startswith("@"):
        return link
    return None


@router.callback_query(F.data == "history")
async def history(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        rows = (await session.execute(select(Transaction).where(Transaction.user_id == user.id).order_by(Transaction.created_at.desc()).limit(20))).scalars().all()
        await session.commit()
    if not rows:
        text = "📜 <b>ІСТОРІЯ</b>\n\nПоки що операцій немає."
    else:
        labels = {"spin": "🎁 Спін", "task": "📋 Завдання", "withdrawal_hold": "💰 Виведення", "withdrawal_refund": "↩️ Повернення", "withdrawal_paid": "✅ Виплачено", "admin_credit": "💵 Адмін-нарахування", "referral_spin": "🎁 Реферальний бонус"}
        lines = [f"{labels.get(r.tx_type, '💫 Операція')} <b>{'+' if Decimal(r.amount) > 0 else ''}{money(Decimal(r.amount))}</b>\n<i>{escape(r.description)}</i>\n🕒 {dt(r.created_at)}" for r in rows]
        text = "📜 <b>ІСТОРІЯ</b>\n\n" + "\n\n".join(lines)
    await callback.message.edit_text(text, reply_markup=back_home())
    await callback.answer()


@router.callback_query(F.data == "rules")
async def rules(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    await callback.message.edit_text(RULES_TEXT, reply_markup=back_home())
    await callback.answer()


@router.callback_query(F.data == "support")
async def support(callback: CallbackQuery) -> None:
    if not await ensure_gate(callback):
        return
    text = (
        "📞 <b>ПІДТРИМКА</b>\n\n"
        "❓ Є питання або проблема?\n\n"
        f"👨‍💻 Адміністратор:\n<b>{escape(settings.support_username)}</b>\n\n"
        "🤝 <b>СПІВПРАЦЯ</b>\n\n"
        f"З питань реклами, партнерства та співпраці:\n<b>{escape(settings.cooperation_username)}</b>"
    )
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    kb.button(text="💬 НАПИСАТИ АДМІНУ", url=f"https://t.me/{settings.support_username.lstrip('@')}")
    kb.button(text="🤝 СПІВПРАЦЯ", url=f"https://t.me/{settings.cooperation_username.lstrip('@')}")
    kb.button(text="🏠 ГОЛОВНЕ МЕНЮ", callback_data="home")
    kb.adjust(1)
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()
