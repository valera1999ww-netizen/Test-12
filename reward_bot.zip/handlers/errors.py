from __future__ import annotations

import logging

from aiogram import Router
from aiogram.types import ErrorEvent

router = Router(name="errors")
logger = logging.getLogger(__name__)


@router.error()
async def on_error(event: ErrorEvent) -> bool:
    logger.exception("Unhandled bot error", exc_info=event.exception)
    return True
