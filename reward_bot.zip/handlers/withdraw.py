from __future__ import annotations

from decimal import Decimal
from html import escape

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from config import settings
from database.models import PayoutMethod, User
from database.session import SessionLocal
from keyboards.user import back_home, main_menu, payout_methods_keyboard
from services.admin import get_setting
from services.payout import create_withdrawal
from services.user import get_or_create_user
from utils.formatting import money
from utils.validators import card_digits, mask_card, parse_decimal

router = Router(name="withdraw")


class WithdrawalStates(StatesGroup):
    waiting_amount = State()
    waiting_details = State()


@router.callback_query(F.data == "withdraw")
async def withdrawal_start(callback: CallbackQuery, state: FSMContext) -> None:
    from handlers.user import ensure_gate
    if not await ensure_gate(callback):
        return
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        methods = (await session.execute(select(PayoutMethod).where(PayoutMethod.is_active.is_(True)).order_by(PayoutMethod.sort_order, PayoutMethod.id))).scalars().all()
        min_amount = Decimal(await get_setting(session, "min_withdrawal", str(settings.min_withdrawal)))
        await session.commit()
    if user.balance < min_amount:
        await callback.message.edit_text(
            "💸 <b>ВИВЕДЕННЯ</b>\n\n"
            f"💰 Баланс: <b>{money(user.balance)}</b>\n"
            f"Мінімальна виплата: <b>{money(min_amount)}</b>\n\n"
            "Недостатньо коштів для створення заявки.",
            reply_markup=back_home(),
        )
        await callback.answer()
        return
    if not methods:
        await callback.message.edit_text("💸 <b>ВИВЕДЕННЯ</b>\n\nНаразі немає активних способів виплати. Звернись до адміністратора.", reply_markup=back_home())
        await callback.answer()
        return
    await state.clear()
    await callback.message.edit_text(
        "💸 <b>ВИВЕДЕННЯ</b>\n\n"
        f"💰 Баланс: <b>{money(user.balance)}</b>\n"
        f"Мінімальна виплата: <b>{money(min_amount)}</b>\n\n"
        "Обери спосіб виплати:",
        reply_markup=payout_methods_keyboard([(m.id, m.name) for m in methods]),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("withdraw:method:"))
async def withdrawal_method(callback: CallbackQuery, state: FSMContext) -> None:
    from handlers.user import ensure_gate
    if not await ensure_gate(callback):
        return
    method_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        method = await session.get(PayoutMethod, method_id)
        await session.commit()
    if not method or not method.is_active:
        await callback.answer("Спосіб виплати недоступний", show_alert=True)
        return
    await state.update_data(method_id=method_id, method_name=method.name)
    await state.set_state(WithdrawalStates.waiting_amount)
    await callback.message.edit_text(f"💳 <b>{escape(method.name)}</b>\n\n💰 Введи суму для виплати:\n\n<i>Наприклад: 50</i>", reply_markup=back_home())
    await callback.answer()


@router.message(WithdrawalStates.waiting_amount)
async def withdrawal_amount(message: Message, state: FSMContext) -> None:
    from handlers.user import ensure_gate
    if not await ensure_gate(message):
        return
    amount = parse_decimal(message.text or "", min_value=Decimal("0.01"))
    if amount is None:
        await message.answer("❌ Введи коректну суму, наприклад <b>50</b>.")
        return
    async with SessionLocal() as session:
        min_amount = Decimal(await get_setting(session, "min_withdrawal", str(settings.min_withdrawal)))
        user = await get_or_create_user(session, message.from_user)
        await session.commit()
    if amount < min_amount:
        await message.answer(f"❌ Мінімальна виплата — <b>{money(min_amount)}</b>.")
        return
    if amount > user.balance:
        await message.answer(f"❌ Недостатньо коштів. Твій баланс — <b>{money(user.balance)}</b>.")
        return
    await state.update_data(amount=str(amount))
    await state.set_state(WithdrawalStates.waiting_details)
    method_name = (await state.get_data()).get("method_name", "спосіб")
    if "карт" in method_name.lower():
        prompt = "💳 Введи номер банківської картки (12–19 цифр)."
    else:
        prompt = f"💳 Введи реквізити для способу <b>{escape(method_name)}</b>."
    await message.answer(prompt)


@router.message(WithdrawalStates.waiting_details)
async def withdrawal_details(message: Message, state: FSMContext) -> None:
    from handlers.user import ensure_gate
    if not await ensure_gate(message):
        return
    data = await state.get_data()
    method_id = int(data["method_id"])
    amount = Decimal(data["amount"])
    details = (message.text or "").strip()
    method_name = data.get("method_name", "спосіб")
    if "карт" in method_name.lower():
        normalized = card_digits(details)
        if not normalized:
            await message.answer("❌ Номер картки має містити від 12 до 19 цифр.")
            return
        details = normalized
        display_details = mask_card(details)
    else:
        if len(details) < 4 or len(details) > 500:
            await message.answer("❌ Введи коректні реквізити.")
            return
        display_details = details if len(details) <= 40 else details[:37] + "..."

    async with SessionLocal() as session:
        async with session.begin():
            try:
                withdrawal = await create_withdrawal(session, message.from_user.id, method_id, amount, details, Decimal(await get_setting(session, "min_withdrawal", str(settings.min_withdrawal))))
            except ValueError as exc:
                await message.answer(f"❌ {escape(str(exc))}")
                return
        user = (await session.execute(select(User).where(User.telegram_id == message.from_user.id))).scalar_one()
        await session.commit()
    await state.clear()
    await message.answer(
        "✅ <b>ЗАЯВКУ СТВОРЕНО</b>\n\n"
        f"💳 Спосіб: <b>{escape(method_name)}</b>\n"
        f"💰 Сума: <b>{money(amount)}</b>\n"
        f"📌 Реквізити: <code>{escape(display_details)}</code>\n\n"
        "⏳ Статус: <b>Очікує</b>\n\n"
        f"💳 Новий баланс: <b>{money(user.balance)}</b>",
        reply_markup=main_menu(),
    )
