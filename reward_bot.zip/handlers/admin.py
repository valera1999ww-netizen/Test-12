from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from decimal import Decimal
from html import escape

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select

from config import settings
from database.models import AdminLog, Broadcast, PayoutMethod, Prize, Task, TaskCompletion, Transaction, User, Withdrawal
from database.session import SessionLocal
from keyboards.admin import (
    admin_menu,
    chance_keyboard,
    confirm_admin,
    payout_admin_keyboard,
    payout_methods_manage,
    simple_admin_back,
    task_admin_keyboard,
    withdrawal_action_keyboard,
)
from services.admin import admin_stats, get_setting, is_admin, log_admin, set_setting
from services.payout import approve_withdrawal, reject_withdrawal
from services.user import get_user_by_tg, get_or_create_user
from utils.formatting import dt, money, tg_user_label
from utils.validators import parse_decimal, parse_int, valid_url

router = Router(name="admin")


class AdminStates(StatesGroup):
    money_user = State()
    money_amount = State()
    money_confirm = State()
    spin_user = State()
    spin_amount = State()
    spin_confirm = State()
    task_name = State()
    task_description = State()
    task_type = State()
    task_link = State()
    task_reward = State()
    task_order = State()
    task_limit = State()
    task_check = State()
    task_active = State()
    task_confirm = State()
    chance_amount = State()
    settings_min = State()
    pm_name = State()
    pm_slug = State()
    pm_edit_name = State()
    broadcast_type = State()
    broadcast_text = State()
    broadcast_media = State()
    broadcast_button_text = State()
    broadcast_button_url = State()
    broadcast_confirm = State()


ADMIN_PREFIX = "👑 <b>АДМІН-ПАНЕЛЬ</b>"


def admin_only(callback: CallbackQuery | Message) -> bool:
    return is_admin(callback.from_user.id, settings.admin_ids)


@router.message(F.text == "/admin")
async def admin_command(message: Message, state: FSMContext) -> None:
    if not admin_only(message):
        return
    await state.clear()
    await message.answer(f"{ADMIN_PREFIX}\n\nОбери розділ керування:", reply_markup=admin_menu())


@router.callback_query(F.data == "admin:menu")
async def admin_home(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        await callback.answer("Немає доступу", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(f"{ADMIN_PREFIX}\n\nОбери розділ керування:", reply_markup=admin_menu())
    await callback.answer()


@router.callback_query(F.data == "admin:stats")
async def admin_stats_view(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        s = await admin_stats(session)
        await session.commit()
    text = (
        "📊 <b>СТАТИСТИКА</b>\n\n"
        f"👥 Всього користувачів: <b>{s['users']}</b>\n"
        f"🟢 Активних за 24 год: <b>{s['active']}</b>\n"
        f"📅 Нових сьогодні: <b>{s['new_today']}</b>\n"
        f"📅 Нових за 7 днів: <b>{s['new_7d']}</b>\n"
        f"🎁 Всього видано спінів: <b>{s['spins']}</b>\n"
        f"💰 Всього нараховано: <b>{money(Decimal(s['credited']))}</b>\n"
        f"💸 Всього виплачено: <b>{money(Decimal(s['paid']))}</b>\n"
        f"📋 Виконано завдань: <b>{s['tasks']}</b>\n"
        f"👥 Всього рефералів: <b>{s['referrals']}</b>"
    )
    await callback.message.edit_text(text, reply_markup=simple_admin_back())
    await callback.answer()


@router.callback_query(F.data == "admin:balance")
async def admin_balance(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        users = (await session.execute(select(User).order_by(User.balance.desc()).limit(15))).scalars().all()
        total = (await session.execute(select(func.coalesce(func.sum(User.balance), 0)))).scalar_one()
        await session.commit()
    lines = [f"{i+1}. {tg_user_label(u.username, u.first_name, u.telegram_id)} — <b>{money(u.balance)}</b>" for i, u in enumerate(users)]
    text = "💰 <b>БАЛАНСИ</b>\n\n" + ("\n".join(lines) if lines else "Немає даних.") + f"\n\n💰 Баланси користувачів: <b>{money(Decimal(total))}</b>"
    await callback.message.edit_text(text, reply_markup=simple_admin_back())
    await callback.answer()


@router.callback_query(F.data == "admin:money")
async def admin_money_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.set_state(AdminStates.money_user)
    await callback.message.edit_text("💵 <b>ВИДАЧА ГРН</b>\n\nВведи Telegram ID користувача:", reply_markup=simple_admin_back())
    await callback.answer()


@router.message(AdminStates.money_user)
async def admin_money_user(message: Message, state: FSMContext) -> None:
    if not admin_only(message):
        return
    user_id = parse_int(message.text or "", min_value=1)
    if user_id is None:
        await message.answer("❌ Некоректний Telegram ID.")
        return
    async with SessionLocal() as session:
        user = await get_user_by_tg(session, user_id)
        await session.commit()
    if not user:
        await message.answer("❌ Користувача не знайдено.")
        return
    await state.update_data(target_user_id=user_id)
    await state.set_state(AdminStates.money_amount)
    await message.answer(f"👤 Користувач: <b>{escape(tg_user_label(user.username, user.first_name, user.telegram_id))}</b>\n\n💰 Введи суму:")


@router.message(AdminStates.money_amount)
async def admin_money_amount(message: Message, state: FSMContext) -> None:
    if not admin_only(message):
        return
    amount = parse_decimal(message.text or "", min_value=Decimal("0.01"))
    if amount is None:
        await message.answer("❌ Вкажи позитивну суму, наприклад 50.")
        return
    data = await state.get_data()
    await state.update_data(amount=str(amount))
    await state.set_state(AdminStates.money_confirm)
    await message.answer(f"👤 Telegram ID: <code>{data['target_user_id']}</code>\n💰 Сума: <b>{money(amount)}</b>\n\nПідтвердити?", reply_markup=confirm_admin("money"))


@router.callback_query(F.data == "admin:confirm:money")
async def admin_money_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    data = await state.get_data()
    target = int(data["target_user_id"])
    amount = Decimal(data["amount"])
    async with SessionLocal() as session:
        async with session.begin():
            user = await session.get(User, (await session.execute(select(User.id).where(User.telegram_id == target))).scalar_one(), with_for_update=True)
            user.balance += amount
            user.total_won += amount
            session.add(Transaction(user_id=user.id, tx_type="admin_credit", amount=amount, balance_after=user.balance, description="💵 Адміністративне нарахування"))
            await log_admin(session, callback.from_user.id, "credit_money", target, {"amount": str(amount)})
        new_balance = user.balance
    await state.clear()
    await callback.message.edit_text(f"✅ <b>Кошти зараховані.</b>\n\n👤 ID: <code>{target}</code>\n💰 +<b>{money(amount)}</b>\n💳 Баланс: <b>{money(new_balance)}</b>", reply_markup=simple_admin_back())
    await callback.answer("Зараховано")


@router.callback_query(F.data == "admin:spins")
async def admin_spins_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.set_state(AdminStates.spin_user)
    await callback.message.edit_text("🎁 <b>ВИДАЧА СПІНІВ</b>\n\nВведи Telegram ID користувача:", reply_markup=simple_admin_back())
    await callback.answer()


@router.message(AdminStates.spin_user)
async def admin_spin_user(message: Message, state: FSMContext) -> None:
    if not admin_only(message):
        return
    user_id = parse_int(message.text or "", min_value=1)
    if user_id is None:
        await message.answer("❌ Некоректний ID.")
        return
    async with SessionLocal() as session:
        user = await get_user_by_tg(session, user_id)
        await session.commit()
    if not user:
        await message.answer("❌ Користувача не знайдено.")
        return
    await state.update_data(target_user_id=user_id)
    await state.set_state(AdminStates.spin_amount)
    await message.answer("🎁 Вкажи кількість спінів. Можна додати позитивне або забрати від'ємне значення.\n\nНаприклад: <b>5</b> або <b>-2</b>")


@router.message(AdminStates.spin_amount)
async def admin_spin_amount(message: Message, state: FSMContext) -> None:
    if not admin_only(message):
        return
    try:
        amount = int((message.text or "").strip())
    except ValueError:
        await message.answer("❌ Введи ціле число, наприклад 5 або -2.")
        return
    if amount == 0 or abs(amount) > 10000:
        await message.answer("❌ Значення має бути від -10000 до 10000 і не дорівнювати нулю.")
        return
    data = await state.get_data()
    async with SessionLocal() as session:
        user = await get_user_by_tg(session, int(data["target_user_id"]))
        await session.commit()
    if not user or user.spins + amount < 0:
        await message.answer("❌ Не можна зробити кількість спінів від'ємною.")
        return
    await state.update_data(amount=amount)
    await state.set_state(AdminStates.spin_confirm)
    await message.answer(f"👤 ID: <code>{data['target_user_id']}</code>\n🎁 Зміна спінів: <b>{amount:+d}</b>\n\nПідтвердити?", reply_markup=confirm_admin("spins"))


@router.callback_query(F.data == "admin:confirm:spins")
async def admin_spin_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    data = await state.get_data()
    target = int(data["target_user_id"])
    amount = int(data["amount"])
    async with SessionLocal() as session:
        async with session.begin():
            user = (await session.execute(select(User).where(User.telegram_id == target).with_for_update())).scalar_one()
            if user.spins + amount < 0:
                await callback.answer("Операцію скасовано: недостатньо спінів", show_alert=True)
                return
            user.spins += amount
            await log_admin(session, callback.from_user.id, "change_spins", target, {"amount": amount})
        new_spins = user.spins
    await state.clear()
    await callback.message.edit_text(f"✅ <b>Спіни змінено.</b>\n\n👤 ID: <code>{target}</code>\n🎁 Зміна: <b>{amount:+d}</b>\n🎁 Новий баланс спінів: <b>{new_spins}</b>", reply_markup=simple_admin_back())
    await callback.answer("Готово")


@router.callback_query(F.data == "admin:tasks")
async def admin_tasks(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        rows = (await session.execute(select(Task).order_by(Task.sort_order, Task.id))).scalars().all()
        await session.commit()
    text = "🎯 <b>КЕРУВАННЯ ЗАВДАННЯМИ</b>\n\n🟢 активне · 🔴 неактивне\nКнопка ⏻ перемикає статус."
    await callback.message.edit_text(text, reply_markup=task_admin_keyboard([(x.id, x.name, x.is_active) for x in rows]))
    await callback.answer()


@router.callback_query(F.data == "admin:task:add")
async def task_add_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.clear()
    await state.set_state(AdminStates.task_name)
    await callback.message.edit_text("➕ <b>НОВЕ ЗАВДАННЯ</b>\n\n1/9. Введи назву завдання:", reply_markup=simple_admin_back("admin:tasks"))
    await callback.answer()


@router.message(AdminStates.task_name)
async def task_name(message: Message, state: FSMContext) -> None:
    value = (message.text or "").strip()
    if not value or len(value) > 255:
        await message.answer("❌ Назва повинна містити 1–255 символів.")
        return
    await state.update_data(name=value)
    await state.set_state(AdminStates.task_description)
    await message.answer("2/9. Введи опис завдання:")


@router.message(AdminStates.task_description)
async def task_description(message: Message, state: FSMContext) -> None:
    await state.update_data(description=(message.text or "").strip())
    await state.set_state(AdminStates.task_type)
    kb = InlineKeyboardBuilder()
    for label, code in [("📢 Підписка", "subscription"), ("👀 Перегляд каналу", "view_channel"), ("🔗 Перехід за посиланням", "link"), ("📣 Інше", "other")]:
        kb.button(text=label, callback_data=f"admin:tasktype:{code}")
    kb.adjust(2)
    await message.answer("3/9. Обери тип завдання:", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("admin:tasktype:"))
async def task_type(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    code = callback.data.split(":")[-1]
    await state.update_data(task_type=code)
    await state.set_state(AdminStates.task_link)
    await callback.message.edit_text("4/9. Введи посилання (https://... або @channel):")
    await callback.answer()


@router.message(AdminStates.task_link)
async def task_link(message: Message, state: FSMContext) -> None:
    value = (message.text or "").strip()
    if not value or not valid_url(value) and not value.startswith("@"):
        await message.answer("❌ Некоректне посилання.")
        return
    await state.update_data(link=value)
    await state.set_state(AdminStates.task_reward)
    await message.answer("5/9. Введи винагороду в гривнях:")


@router.message(AdminStates.task_reward)
async def task_reward(message: Message, state: FSMContext) -> None:
    amount = parse_decimal(message.text or "", min_value=Decimal("0.01"), max_value=Decimal("100000"))
    if amount is None:
        await message.answer("❌ Некоректна сума.")
        return
    await state.update_data(reward=str(amount))
    await state.set_state(AdminStates.task_order)
    await message.answer("6/9. Введи порядок відображення (наприклад 10):")


@router.message(AdminStates.task_order)
async def task_order(message: Message, state: FSMContext) -> None:
    value = parse_int(message.text or "", min_value=0, max_value=100000)
    if value is None:
        await message.answer("❌ Введи ціле число від 0 до 100000.")
        return
    await state.update_data(sort_order=value)
    await state.set_state(AdminStates.task_limit)
    await message.answer("7/9. Максимальна кількість виконань. Введи число або <b>0</b> для безліміту:")


@router.message(AdminStates.task_limit)
async def task_limit(message: Message, state: FSMContext) -> None:
    value = parse_int(message.text or "", min_value=0, max_value=10_000_000)
    if value is None:
        await message.answer("❌ Введи ціле число.")
        return
    await state.update_data(max_completions=None if value == 0 else value)
    await state.set_state(AdminStates.task_check)
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Так", callback_data="admin:bool:check:1")
    kb.button(text="❌ Ні", callback_data="admin:bool:check:0")
    await message.answer("8/9. Чи потрібна перевірка виконання?", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("admin:bool:check:"))
async def task_check_flag(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.update_data(requires_check=callback.data.endswith(":1"))
    await state.set_state(AdminStates.task_active)
    kb = InlineKeyboardBuilder()
    kb.button(text="🟢 Активне", callback_data="admin:bool:active:1")
    kb.button(text="🔴 Неактивне", callback_data="admin:bool:active:0")
    await callback.message.edit_text("9/9. Зробити завдання активним одразу?", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("admin:bool:active:"))
async def task_active_flag(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    data = await state.get_data()
    data["is_active"] = callback.data.endswith(":1")
    await state.update_data(**data)
    await state.set_state(AdminStates.task_confirm)
    preview = (
        "📋 <b>НОВЕ ЗАВДАННЯ</b>\n\n"
        f"Назва: <b>{escape(data['name'])}</b>\n"
        f"Тип: <b>{escape(data['task_type'])}</b>\n"
        f"Нагорода: <b>{money(Decimal(data['reward']))}</b>\n"
        f"Посилання: <code>{escape(data['link'])}</code>\n"
        f"Порядок: <b>{data['sort_order']}</b>\n"
        f"Ліміт: <b>{data['max_completions'] or 'безліміт'}</b>\n"
        f"Перевірка: <b>{'так' if data['requires_check'] else 'ні'}</b>\n"
        f"Статус: <b>{'активне' if data['is_active'] else 'неактивне'}</b>\n\n"
        f"Опис: {escape(data['description'])}"
    )
    await callback.message.edit_text(preview, reply_markup=confirm_admin("task"))
    await callback.answer()


@router.callback_query(F.data == "admin:confirm:task")
async def task_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    data = await state.get_data()
    async with SessionLocal() as session:
        async with session.begin():
            task = Task(
                name=data["name"], description=data["description"], task_type=data["task_type"], link=data["link"],
                reward=Decimal(data["reward"]), sort_order=int(data["sort_order"]), max_completions=data["max_completions"],
                requires_check=bool(data["requires_check"]), is_active=bool(data["is_active"]),
            )
            session.add(task)
            await log_admin(session, callback.from_user.id, "create_task", payload={"name": data["name"]})
    await state.clear()
    await callback.message.edit_text("✅ <b>Завдання додано.</b>", reply_markup=simple_admin_back("admin:tasks"))
    await callback.answer()


@router.callback_query(F.data.startswith("admin:task:toggle:"))
async def task_toggle(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    task_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        async with session.begin():
            task = await session.get(Task, task_id, with_for_update=True)
            if task:
                task.is_active = not task.is_active
                await log_admin(session, callback.from_user.id, "toggle_task", payload={"task_id": task_id, "is_active": task.is_active})
        rows = (await session.execute(select(Task).order_by(Task.sort_order, Task.id))).scalars().all()
    await callback.message.edit_reply_markup(reply_markup=task_admin_keyboard([(x.id, x.name, x.is_active) for x in rows]))
    await callback.answer("Статус змінено")


@router.callback_query(F.data.startswith("admin:task:view:"))
async def task_view_admin(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    task_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        task = await session.get(Task, task_id)
        count = (await session.execute(select(func.count()).select_from(TaskCompletion).where(TaskCompletion.task_id == task_id))).scalar_one() if task else 0
        await session.commit()
    if not task:
        await callback.answer("Не знайдено", show_alert=True)
        return
    text = f"🎯 <b>{escape(task.name)}</b>\n\n{escape(task.description)}\n\n💰 Нагорода: <b>{money(task.reward)}</b>\n🔗 {escape(task.link)}\n🟢 Активне: <b>{'так' if task.is_active else 'ні'}</b>\n✅ Перевірка: <b>{'так' if task.requires_check else 'ні'}</b>\n📈 Ліміт: <b>{task.max_completions or 'безліміт'}</b>\n📊 Виконань: <b>{count}</b>"
    await callback.message.edit_text(text, reply_markup=simple_admin_back("admin:tasks"))
    await callback.answer()


@router.callback_query(F.data == "admin:chances")
async def chances(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        prizes = (await session.execute(select(Prize).order_by(Prize.sort_order, Prize.id))).scalars().all()
        await session.commit()
    total = sum((Decimal(x.chance) for x in prizes), Decimal(0))
    text = "🎲 <b>ШАНСИ ПРИЗІВ</b>\n\n" + "\n".join(f"{money(p.amount).replace(' грн','')} грн — <b>{Decimal(p.chance):g}%</b>" for p in prizes) + f"\n\nΣ Разом: <b>{total:g}%</b>\n\nЗбереження дозволяється лише при точній сумі 100%."
    await callback.message.edit_text(text, reply_markup=chance_keyboard([(p.id, f"{money(p.amount).replace(' грн','')} грн", f"{Decimal(p.chance):g}%") for p in prizes]))
    await callback.answer()


@router.callback_query(F.data.startswith("admin:chance:edit:"))
async def chance_edit_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    prize_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        prize = await session.get(Prize, prize_id)
        await session.commit()
    if not prize:
        await callback.answer("Приз не знайдено", show_alert=True)
        return
    await state.update_data(prize_id=prize_id)
    await state.set_state(AdminStates.chance_amount)
    await callback.message.edit_text(f"🎲 <b>Шанс для {money(prize.amount)}</b>\n\nВведи новий відсоток:", reply_markup=simple_admin_back("admin:chances"))
    await callback.answer()


@router.message(AdminStates.chance_amount)
async def chance_edit_save(message: Message, state: FSMContext) -> None:
    value = parse_decimal(message.text or "", min_value=Decimal("0"), max_value=Decimal("100"))
    if value is None:
        await message.answer("❌ Значення має бути від 0 до 100.")
        return
    data = await state.get_data()
    async with SessionLocal() as session:
        async with session.begin():
            prize = await session.get(Prize, int(data["prize_id"]), with_for_update=True)
            prize.chance = value
            prizes = (await session.execute(select(Prize).where(Prize.is_active.is_(True)))).scalars().all()
            total = sum((Decimal(p.chance) for p in prizes), Decimal(0))
            if total != Decimal("100"):
                await session.rollback()
                await message.answer(f"❌ Не збережено. Сума шансів після зміни = <b>{total:g}%</b>. Потрібно рівно 100%.")
                return
            await log_admin(session, message.from_user.id, "update_prize_chance", payload={"prize_id": int(data["prize_id"]), "chance": str(value)})
    await state.clear()
    await message.answer("✅ Шанс збережено. Сума шансів = <b>100%</b>.", reply_markup=simple_admin_back("admin:chances"))


@router.callback_query(F.data == "admin:payout_methods")
async def admin_payout_methods(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        items = (await session.execute(select(PayoutMethod).order_by(PayoutMethod.sort_order, PayoutMethod.id))).scalars().all()
        await session.commit()
    await callback.message.edit_text("💳 <b>СПОСОБИ ВИПЛАТ</b>\n\n🟢 активний · 🔴 вимкнений", reply_markup=payout_methods_manage([(x.id, x.name, x.is_active) for x in items]))
    await callback.answer()


@router.callback_query(F.data == "admin:pm:add")
async def admin_pm_add(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.set_state(AdminStates.pm_name)
    await callback.message.edit_text("➕ Введи назву нового способу виплати:\n\nНаприклад: <b>Банківська картка</b>")
    await callback.answer()


@router.message(AdminStates.pm_name)
async def admin_pm_name(message: Message, state: FSMContext) -> None:
    name = (message.text or "").strip()
    if not name or len(name) > 255:
        await message.answer("❌ Некоректна назва.")
        return
    await state.update_data(name=name)
    await state.set_state(AdminStates.pm_slug)
    await message.answer("Введи технічний slug латиницею, наприклад <b>bank_card</b>:")


@router.message(AdminStates.pm_slug)
async def admin_pm_slug(message: Message, state: FSMContext) -> None:
    slug = (message.text or "").strip().lower().replace(" ", "_")
    if not slug or len(slug) > 100 or not slug.replace("_", "").isalnum():
        await message.answer("❌ Некоректний slug.")
        return
    data = await state.get_data()
    async with SessionLocal() as session:
        async with session.begin():
            session.add(PayoutMethod(name=data["name"], slug=slug, sort_order=0, is_active=True))
            await log_admin(session, message.from_user.id, "create_payout_method", payload={"name": data["name"], "slug": slug})
    await state.clear()
    await message.answer("✅ Спосіб виплати додано.", reply_markup=simple_admin_back("admin:payout_methods"))


@router.callback_query(F.data.startswith("admin:pm:edit:"))
async def admin_pm_edit_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    item_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        item = await session.get(PayoutMethod, item_id)
        await session.commit()
    if not item:
        await callback.answer("Спосіб не знайдено", show_alert=True)
        return
    await state.update_data(pm_edit_id=item_id)
    await state.set_state(AdminStates.pm_edit_name)
    await callback.message.edit_text(f"✏️ <b>Редагування способу виплати</b>\n\nПоточна назва: <b>{escape(item.name)}</b>\n\nВведи нову назву:")
    await callback.answer()


@router.message(AdminStates.pm_edit_name)
async def admin_pm_edit_save(message: Message, state: FSMContext) -> None:
    if not admin_only(message):
        return
    name = (message.text or "").strip()
    if not name or len(name) > 255:
        await message.answer("❌ Некоректна назва.")
        return
    data = await state.get_data()
    async with SessionLocal() as session:
        async with session.begin():
            item = await session.get(PayoutMethod, int(data["pm_edit_id"]), with_for_update=True)
            if not item:
                await message.answer("❌ Спосіб не знайдено.")
                return
            item.name = name
            await log_admin(session, message.from_user.id, "edit_payout_method", payload={"id": item.id, "name": name})
    await state.clear()
    await message.answer("✅ Назву способу виплати змінено.", reply_markup=simple_admin_back("admin:payout_methods"))


@router.callback_query(F.data.startswith("admin:pm:toggle:"))
async def admin_pm_toggle(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    item_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        async with session.begin():
            item = await session.get(PayoutMethod, item_id, with_for_update=True)
            if item:
                item.is_active = not item.is_active
                await log_admin(session, callback.from_user.id, "toggle_payout_method", payload={"id": item_id, "active": item.is_active})
        items = (await session.execute(select(PayoutMethod).order_by(PayoutMethod.id))).scalars().all()
    await callback.message.edit_reply_markup(reply_markup=payout_methods_manage([(x.id, x.name, x.is_active) for x in items]))
    await callback.answer("Статус змінено")


@router.callback_query(F.data.startswith("admin:pm:delete:"))
async def admin_pm_delete(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    item_id = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        async with session.begin():
            item = await session.get(PayoutMethod, item_id, with_for_update=True)
            if item:
                # Keep the historical reference in withdrawal rows; soft-delete instead of physical deletion.
                item.is_active = False
                await log_admin(session, callback.from_user.id, "disable_payout_method", payload={"id": item_id})
    await admin_payout_methods(callback)


@router.callback_query(F.data == "admin:settings")
async def admin_settings(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    min_w = Decimal(settings.min_withdrawal)
    async with SessionLocal() as session:
        min_w = Decimal(await get_setting(session, "min_withdrawal", str(min_w)))
        await session.commit()
    kb = InlineKeyboardBuilder()
    kb.button(text="✏️ Змінити мінімальну виплату", callback_data="admin:settings:min")
    kb.button(text="🏠 Адмін-панель", callback_data="admin:menu")
    kb.adjust(1)
    await callback.message.edit_text(f"⚙️ <b>НАЛАШТУВАННЯ</b>\n\n💸 Мінімальна виплата: <b>{money(min_w)}</b>\n📢 Канал: <code>{escape(settings.required_channel_id)}</code>", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "admin:settings:min")
async def admin_settings_min(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.set_state(AdminStates.settings_min)
    await callback.message.edit_text("⚙️ Введи нову мінімальну виплату в грн:")
    await callback.answer()


@router.message(AdminStates.settings_min)
async def admin_settings_min_save(message: Message, state: FSMContext) -> None:
    value = parse_decimal(message.text or "", min_value=Decimal("0.01"), max_value=Decimal("1000000"))
    if value is None:
        await message.answer("❌ Некоректна сума.")
        return
    async with SessionLocal() as session:
        async with session.begin():
            await set_setting(session, "min_withdrawal", str(value))
            await log_admin(session, message.from_user.id, "set_min_withdrawal", payload={"value": str(value)})
    await state.clear()
    await message.answer(f"✅ Мінімальну виплату встановлено: <b>{money(value)}</b>", reply_markup=simple_admin_back("admin:settings"))


@router.callback_query(F.data == "admin:channels")
async def admin_channels(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    text = "📢 <b>КАНАЛИ</b>\n\nОсновний канал підписки задається у <code>.env</code>:\n\n" + f"ID: <code>{escape(settings.required_channel_id)}</code>\nПосилання: {escape(settings.required_channel_url)}\n\nДля перевірки підписки бот повинен мати права адміністратора каналу."
    await callback.message.edit_text(text, reply_markup=simple_admin_back())
    await callback.answer()


@router.callback_query(F.data == "admin:users")
async def admin_users(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        users = (await session.execute(select(User).order_by(User.created_at.desc()).limit(20))).scalars().all()
        await session.commit()
    lines = [f"{i+1}. {tg_user_label(u.username, u.first_name, u.telegram_id)} — 💰 {money(u.balance)} — 🎁 {u.spins}" for i, u in enumerate(users)]
    await callback.message.edit_text("👥 <b>КОРИСТУВАЧІ · ОСТАННІ 20</b>\n\n" + ("\n".join(lines) if lines else "Немає користувачів."), reply_markup=simple_admin_back())
    await callback.answer()


@router.callback_query(F.data == "admin:withdrawals")
async def admin_withdrawals(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        rows = (await session.execute(select(Withdrawal).where(Withdrawal.status == "pending").order_by(Withdrawal.created_at))).scalars().all()
        result = []
        for w in rows:
            user = await session.get(User, w.user_id)
            method = await session.get(PayoutMethod, w.method_id)
            result.append((w.id, f"#{w.id} · {money(w.amount)} · {user.username or user.telegram_id}", "⏳"))
        await session.commit()
    if not result:
        text = "💸 <b>ВИПЛАТИ</b>\n\n⏳ Немає необроблених заявок."
    else:
        text = "💸 <b>ВИПЛАТИ</b>\n\nОберіть заявку:"
    await callback.message.edit_text(text, reply_markup=payout_admin_keyboard(result) if result else simple_admin_back())
    await callback.answer()


@router.callback_query(F.data.startswith("admin:withdraw:view:"))
async def admin_withdraw_view(callback: CallbackQuery) -> None:
    wid = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        w = await session.get(Withdrawal, wid)
        user = await session.get(User, w.user_id) if w else None
        method = await session.get(PayoutMethod, w.method_id) if w else None
        await session.commit()
    if not w or not user:
        await callback.answer("Заявка не знайдена", show_alert=True)
        return
    details = w.payment_details
    label = "💳 Номер картки" if method and "карт" in method.name.lower() else "📌 Реквізити"
    text = f"💸 <b>ЗАЯВКА #{w.id}</b>\n\n👤 Користувач: {tg_user_label(user.username, user.first_name, user.telegram_id)}\n🆔 ID: <code>{user.telegram_id}</code>\n💳 Спосіб: <b>{escape(method.name if method else '—')}</b>\n💰 Сума: <b>{money(w.amount)}</b>\n{label}: <code>{escape(details)}</code>\n🕒 Створено: {dt(w.created_at)}\n\n⏳ Статус: <b>{escape(w.status)}</b>"
    await callback.message.edit_text(text, reply_markup=withdrawal_action_keyboard(w.id))
    await callback.answer()


@router.callback_query(F.data.startswith("admin:withdraw:paid:"))
async def admin_withdraw_paid(callback: CallbackQuery, bot: Bot) -> None:
    wid = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        async with session.begin():
            try:
                w = await approve_withdrawal(session, wid)
            except ValueError as exc:
                await callback.answer(str(exc), show_alert=True)
                return
            user = await session.get(User, w.user_id)
            await log_admin(session, callback.from_user.id, "withdrawal_paid", user.telegram_id if user else None, {"withdrawal_id": wid, "amount": str(w.amount)})
    if user:
        try:
            await bot.send_message(user.telegram_id, f"✅ <b>ВИПЛАТУ ПІДТВЕРДЖЕНО</b>\n\n💰 Сума: <b>{money(w.amount)}</b>\n💸 Заявка #{wid}")
        except Exception as exc:
            logging.getLogger(__name__).warning("Failed to notify user %s about withdrawal #%s: %s", user.telegram_id if user else None, wid, exc)
    await callback.message.edit_text(f"✅ <b>Заявку #{wid} позначено як виплачену.</b>", reply_markup=simple_admin_back("admin:withdrawals"))
    await callback.answer("Виплату підтверджено")


@router.callback_query(F.data.startswith("admin:withdraw:reject:"))
async def admin_withdraw_reject(callback: CallbackQuery, bot: Bot) -> None:
    wid = int(callback.data.split(":")[-1])
    async with SessionLocal() as session:
        async with session.begin():
            try:
                w = await reject_withdrawal(session, wid, "Відхилено адміністратором")
            except ValueError as exc:
                await callback.answer(str(exc), show_alert=True)
                return
            user = await session.get(User, w.user_id)
            await log_admin(session, callback.from_user.id, "withdrawal_rejected", user.telegram_id if user else None, {"withdrawal_id": wid, "amount": str(w.amount)})
    if user:
        try:
            await bot.send_message(user.telegram_id, f"❌ <b>ВИПЛАТУ ВІДХИЛЕНО</b>\n\n💰 Повернуто: <b>{money(w.amount)}</b>\n💸 Заявка #{wid}")
        except Exception as exc:
            logging.getLogger(__name__).warning("Failed to notify user %s about withdrawal #%s: %s", user.telegram_id if user else None, wid, exc)
    await callback.message.edit_text(f"❌ <b>Заявку #{wid} відхилено.</b>\n\nСума повернена користувачу.", reply_markup=simple_admin_back("admin:withdrawals"))
    await callback.answer("Заявку відхилено")


@router.callback_query(F.data == "admin:logs")
async def admin_logs(callback: CallbackQuery) -> None:
    if not admin_only(callback):
        return
    async with SessionLocal() as session:
        logs = (await session.execute(select(AdminLog).order_by(AdminLog.created_at.desc()).limit(30))).scalars().all()
        await session.commit()
    if not logs:
        text = "📜 <b>ЛОГИ</b>\n\nЛогів ще немає."
    else:
        lines = [f"🧾 <b>{escape(l.action)}</b> · адмін <code>{l.admin_telegram_id}</code> · {dt(l.created_at)}" for l in logs]
        text = "📜 <b>ЛОГИ</b>\n\n" + "\n".join(lines)
    await callback.message.edit_text(text, reply_markup=simple_admin_back())
    await callback.answer()


# ---------------------- Broadcasts ----------------------

@router.callback_query(F.data == "admin:broadcast")
async def broadcast_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.clear()
    await state.set_state(AdminStates.broadcast_type)
    kb = InlineKeyboardBuilder()
    kb.button(text="📝 Тільки текст", callback_data="admin:bc:type:text")
    kb.button(text="🖼 Фото", callback_data="admin:bc:type:photo")
    kb.button(text="🎥 Відео", callback_data="admin:bc:type:video")
    kb.adjust(1)
    await callback.message.edit_text("📢 <b>РОЗСИЛКА</b>\n\nОбери тип повідомлення:", reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data.startswith("admin:bc:type:"))
async def broadcast_type(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    bc_type = callback.data.split(":")[-1]
    await state.update_data(broadcast_type=bc_type)
    if bc_type == "text":
        await state.set_state(AdminStates.broadcast_text)
        await callback.message.edit_text("📝 Введи текст розсилки:")
    else:
        await state.set_state(AdminStates.broadcast_text)
        await callback.message.edit_text("📝 Введи текст/підпис до медіа:")
    await callback.answer()


@router.message(AdminStates.broadcast_text)
async def broadcast_text(message: Message, state: FSMContext) -> None:
    await state.update_data(text=message.text or "", photo=None, video=None)
    data = await state.get_data()
    if data["broadcast_type"] == "text":
        await state.set_state(AdminStates.broadcast_button_text)
        await message.answer("🔘 Введи текст кнопки або <b>-</b>, якщо кнопка не потрібна:")
    else:
        await state.set_state(AdminStates.broadcast_media)
        await message.answer("🖼 Тепер надішли фото/відео для розсилки:")


@router.message(AdminStates.broadcast_media)
async def broadcast_media(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    if data["broadcast_type"] == "photo" and not message.photo:
        await message.answer("❌ Надішли саме фото.")
        return
    if data["broadcast_type"] == "video" and not message.video:
        await message.answer("❌ Надішли саме відео.")
        return
    if message.photo:
        file_id = message.photo[-1].file_id
    else:
        file_id = message.video.file_id
    await state.update_data(file_id=file_id)
    await state.set_state(AdminStates.broadcast_button_text)
    await message.answer("🔘 Введи текст кнопки або <b>-</b>, якщо кнопка не потрібна:")


@router.message(AdminStates.broadcast_button_text)
async def broadcast_button_text(message: Message, state: FSMContext) -> None:
    value = (message.text or "").strip()
    if value == "-":
        await state.update_data(button_text=None, button_url=None)
        await broadcast_preview(message, state)
        return
    if not value or len(value) > 100:
        await message.answer("❌ Некоректний текст кнопки.")
        return
    await state.update_data(button_text=value)
    await state.set_state(AdminStates.broadcast_button_url)
    await message.answer("🔗 Введи URL кнопки (https://...):")


@router.message(AdminStates.broadcast_button_url)
async def broadcast_button_url(message: Message, state: FSMContext) -> None:
    url = (message.text or "").strip()
    if not valid_url(url) or not url.startswith(("http://", "https://", "tg://")):
        await message.answer("❌ Некоректний URL.")
        return
    await state.update_data(button_url=url)
    await broadcast_preview(message, state)


async def broadcast_preview(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    kb = InlineKeyboardBuilder()
    if data.get("button_text") and data.get("button_url"):
        kb.button(text=data["button_text"], url=data["button_url"])
    kb.row(InlineKeyboardButton(text="✅ ВІДПРАВИТИ ВСІМ", callback_data="admin:bc:confirm"), InlineKeyboardButton(text="❌ СКАСУВАТИ", callback_data="admin:cancel"))
    preview = "📢 <b>ПОПЕРЕДНІЙ ПЕРЕГЛЯД</b>\n\n" + escape(data.get("text") or "")
    await state.set_state(AdminStates.broadcast_confirm)
    await message.answer(preview, reply_markup=kb.as_markup())


@router.callback_query(F.data == "admin:bc:confirm")
async def broadcast_confirm(callback: CallbackQuery, state: FSMContext, bot: Bot) -> None:
    if not admin_only(callback):
        return
    data = await state.get_data()
    async with SessionLocal() as session:
        broadcast = Broadcast(
            admin_telegram_id=callback.from_user.id,
            content_type=data["broadcast_type"],
            text=data.get("text"),
            file_id=data.get("file_id"),
            button_text=data.get("button_text"),
            button_url=data.get("button_url"),
        )
        session.add(broadcast)
        await session.commit()
        result = await session.execute(select(User.telegram_id).where(User.is_blocked.is_(False)))
        user_ids = [row[0] for row in result.all()]
        broadcast_id = broadcast.id
    await state.clear()
    await callback.message.edit_text(f"📢 <b>Розсилку #{broadcast_id} запущено.</b>\n\n👥 Отримувачів: <b>{len(user_ids)}</b>")

    delivered = 0
    failed = 0
    button_markup = None
    if data.get("button_text") and data.get("button_url"):
        builder = InlineKeyboardBuilder()
        builder.button(text=data["button_text"], url=data["button_url"])
        button_markup = builder.as_markup()
    for tg_id in user_ids:
        try:
            content_type = data["broadcast_type"]
            if content_type == "text":
                await bot.send_message(tg_id, data.get("text", ""), reply_markup=button_markup)
            elif content_type == "photo":
                await bot.send_photo(tg_id, data["file_id"], caption=data.get("text", ""), reply_markup=button_markup)
            else:
                await bot.send_video(tg_id, data["file_id"], caption=data.get("text", ""), reply_markup=button_markup)
            delivered += 1
        except TelegramForbiddenError:
            failed += 1
            async with SessionLocal() as session:
                async with session.begin():
                    user = (await session.execute(select(User).where(User.telegram_id == tg_id).with_for_update())).scalar_one_or_none()
                    if user:
                        user.is_blocked = True
        except TelegramBadRequest:
            failed += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.06)
    async with SessionLocal() as session:
        async with session.begin():
            b = await session.get(Broadcast, broadcast_id, with_for_update=True)
            if b:
                b.sent_count = len(user_ids)
                b.delivered_count = delivered
                b.failed_count = failed
                b.finished_at = datetime.now(timezone.utc)
    await callback.message.answer(f"✅ <b>РОЗСИЛКУ ЗАВЕРШЕНО</b>\n\n📢 Відправлено: <b>{len(user_ids)}</b>\n✅ Доставлено: <b>{delivered}</b>\n❌ Помилки: <b>{failed}</b>", reply_markup=simple_admin_back("admin:menu"))


@router.callback_query(F.data == "admin:cancel")
async def admin_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback):
        return
    await state.clear()
    await callback.message.edit_text("❌ <b>Скасовано.</b>", reply_markup=admin_menu())
    await callback.answer()
